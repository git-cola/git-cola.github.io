from cola.classic.controller import cola_classic
from cola.classic.controller import widget as classic_widget
