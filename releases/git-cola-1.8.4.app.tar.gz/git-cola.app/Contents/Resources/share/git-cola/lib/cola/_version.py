# The current git-cola version
VERSION = '1.8.4'
