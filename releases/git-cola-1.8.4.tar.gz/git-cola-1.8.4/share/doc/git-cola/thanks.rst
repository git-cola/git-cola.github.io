Thanks
======
`git-cola` was made possible thanks to the contributions of the following people:

* Andreas Sommer
* Audrius Karabanovas
* Barry Roberts
* Boris W
* Ben Boeckel
* Christian Jann
* Daniel King
* Daniel Fahlke
* David Aguilar
* David Martínez Martí
* Eric Drechsel
* `GIT Hackers <http://git-scm.com/about>`_
* Glen Mailer
* Guillaume de Bure
* Ingo Weinhold
* Ismael Juma
* Iulian Udrea
* Ivar Smolin
* Jakub Wilk
* Johann Schmitz
* Jeff Dagenais
* Justin Lecher
* Karl Bielefeldt
* Karthik Manamcheri
* Kelvie Wong
* Kerrick Staley
* Kevin Kofler
* Libor Jelinek
* Maciej Filipiak
* Mahmoud Hossam
* Marco Costalba
* Markus Heidelberg
* Maarten Nieber
* Matthew Levine
* Michael Geddes
* Michael Homer
* Omega Weapon
* Paolo G. Giarrusso
* Peter Júnoš
* Rustam Safin
* Sergey Leschina
* Stefan Naewe
* Steffen Prohaska
* Sven Claussner
* Ugo Riboni
* Uri Okrent
