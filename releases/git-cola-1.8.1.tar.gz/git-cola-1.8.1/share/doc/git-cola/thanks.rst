Thanks
======
`git-cola` was made possible thanks to the contributions of the following people:

* Andreas Sommer
* Audrius Karabanovas
* Barry Roberts
* Boris W
* Ben Boeckel
* Christian Jann
* Daniel King
* Daniel Fahlke
* David Aguilar
* David Martínez Martí
* Eric Drechsel
* `GIT Hackers <http://git-scm.com/about>`_
* Guillaume de Bure
* Ingo Weinhold
* Ismael Juma
* Iulian Udrea
* Johann Schmitz
* Justin Lecher
* Karl Bielefeldt
* Karthik Manamcheri
* Kelvie Wong
* Kevin Kofler
* Libor Jelinek
* Mahmoud Hossam
* Marco Costalba
* Markus Heidelberg
* Matthew Levine
* Michael Geddes
* Michael Homer
* Omega Weapon
* Paolo G. Giarrusso
* Stefan Naewe
* Steffen Prohaska
* Ugo Riboni
* Uri Okrent
