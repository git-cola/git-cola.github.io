===================================
Welcome to git-cola's Documentation
===================================
.. toctree::

    intro
    tools
    mainwindow
    thanks

Release Notes
=============
.. toctree::
    :maxdepth: 1

    relnotes

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
